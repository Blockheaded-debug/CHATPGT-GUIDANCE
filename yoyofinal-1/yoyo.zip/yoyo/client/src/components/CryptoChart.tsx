import { useEffect, useRef, useState } from 'react';
import { createChart, IChartApi, ISeriesApi, UTCTimestamp, CandlestickSeries, HistogramSeries } from 'lightweight-charts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, Activity, BarChart3 } from 'lucide-react';
import { cryptoApi, priceUpdater } from '@/lib/cryptoApi';
import { backendCryptoApi } from '@/lib/backendCryptoApi';
import { cn } from '@/lib/utils';

interface CryptoChartProps {
  symbol?: string;
  height?: number;
  className?: string;
}

interface PriceData {
  time: UTCTimestamp;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

const SUPPORTED_SYMBOLS = [
  { symbol: 'BTCUSDT', name: 'Bitcoin', icon: '₿' },
  { symbol: 'ETHUSDT', name: 'Ethereum', icon: 'Ξ' },
  { symbol: 'BNBUSDT', name: 'BNB', icon: 'B' },
  { symbol: 'ADAUSDT', name: 'Cardano', icon: 'A' },
  { symbol: 'DOTUSDT', name: 'Polkadot', icon: '●' },
  { symbol: 'LINKUSDT', name: 'Chainlink', icon: '⛓' },
  { symbol: 'MATICUSDT', name: 'Polygon', icon: 'M' }
];

export default function CryptoChart({ 
  symbol = 'BTCUSDT', 
  height = 400, 
  className 
}: CryptoChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  
  const [selectedSymbol, setSelectedSymbol] = useState(symbol);
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [priceChange24h, setPriceChange24h] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height,
      layout: {
        background: { color: 'transparent' },
        textColor: 'rgb(156, 163, 175)', // text-gray-400
      },
      grid: {
        vertLines: { color: 'rgba(156, 163, 175, 0.1)' },
        horzLines: { color: 'rgba(156, 163, 175, 0.1)' },
      },
      crosshair: {
        mode: 1,
        vertLine: {
          color: 'rgba(59, 130, 246, 0.5)', // blue-500
          width: 1,
          style: 3,
        },
        horzLine: {
          color: 'rgba(59, 130, 246, 0.5)', // blue-500
          width: 1,
          style: 3,
        },
      },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        borderColor: 'rgba(156, 163, 175, 0.2)',
      },
      rightPriceScale: {
        borderColor: 'rgba(156, 163, 175, 0.2)',
      },
    });

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: 'rgb(34, 197, 94)', // green-500
      downColor: 'rgb(239, 68, 68)', // red-500
      borderVisible: false,
      wickUpColor: 'rgb(34, 197, 94)',
      wickDownColor: 'rgb(239, 68, 68)',
    });

    const volumeSeries = chart.addSeries(HistogramSeries, {
      color: 'rgba(156, 163, 175, 0.3)',
      priceFormat: {
        type: 'volume',
      },
      priceScaleId: 'volume',
    });

    chart.priceScale('volume').applyOptions({
      scaleMargins: {
        top: 0.8,
        bottom: 0,
      },
    });

    chartRef.current = chart;
    candlestickSeriesRef.current = candlestickSeries;
    volumeSeriesRef.current = volumeSeries;

    // Handle resize
    const handleResize = () => {
      if (chartContainerRef.current && chart) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chart) {
        chart.remove();
      }
    };
  }, [height]);

  // Load chart data when symbol changes - optimized with backend integration
  useEffect(() => {
    if (!chartRef.current || !candlestickSeriesRef.current) return;

    const loadData = async () => {
      setIsLoading(true);
      setError(null);

      try {
        // Try backend API first for optimized performance
        let candlestickData;
        try {
          candlestickData = await backendCryptoApi.getCandlestickData(selectedSymbol, '15m', 200);
        } catch (backendError) {
          console.warn('Backend API failed, falling back to frontend API:', backendError);
          candlestickData = await cryptoApi.getCandlestickData(selectedSymbol, '15m', 200);
        }
        
        // Transform data for TradingView
        const chartData: PriceData[] = candlestickData.map(item => ({
          time: Math.floor(item.time / 1000) as UTCTimestamp,
          open: item.open,
          high: item.high,
          low: item.low,
          close: item.close,
        }));

        const volumeData = candlestickData
          .filter(item => item.volume !== undefined)
          .map(item => ({
            time: Math.floor(item.time / 1000) as UTCTimestamp,
            value: item.volume!,
            color: item.close >= item.open ? 'rgba(34, 197, 94, 0.3)' : 'rgba(239, 68, 68, 0.3)',
          }));

        // Update chart series
        candlestickSeriesRef.current!.setData(chartData);
        if (volumeSeriesRef.current && volumeData.length > 0) {
          volumeSeriesRef.current.setData(volumeData);
        }

        // Get current price with backend optimization
        let priceData;
        try {
          priceData = await backendCryptoApi.getCurrentPrice(selectedSymbol);
        } catch (backendError) {
          console.warn('Backend price API failed, falling back:', backendError);
          priceData = await cryptoApi.getCurrentPrice(selectedSymbol);
        }
        
        setCurrentPrice(priceData.price);
        setPriceChange24h(priceData.change24h);

      } catch (error) {
        console.error('Failed to load chart data:', error);
        setError(`Failed to load data for ${selectedSymbol}`);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedSymbol]);

  // Subscribe to real-time price updates with backend optimization
  useEffect(() => {
    // Try backend subscription first, fallback to frontend if needed
    let unsubscribe: (() => void) | null = null;
    
    try {
      unsubscribe = backendCryptoApi.subscribeToPrice(selectedSymbol, (price, change24h) => {
        setCurrentPrice(price);
        setPriceChange24h(change24h);
      });
    } catch (error) {
      console.warn('Backend price subscription failed, using frontend:', error);
      unsubscribe = priceUpdater.subscribe(selectedSymbol, (price, change24h) => {
        setCurrentPrice(price);
        setPriceChange24h(change24h);
      });
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [selectedSymbol]);

  const formatPrice = (price: number) => {
    if (price >= 1) {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 8,
      }).format(price);
    } else {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 6,
        maximumFractionDigits: 10,
      }).format(price);
    }
  };

  const formatChange = (change: number) => {
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
  };

  const selectedCrypto = SUPPORTED_SYMBOLS.find(s => s.symbol === selectedSymbol);

  return (
    <Card className={cn('w-full', className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Real-time Crypto Charts
            </CardTitle>
            {selectedCrypto && (
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedCrypto.icon}</span>
                <div>
                  <div className="font-semibold">{selectedCrypto.name}</div>
                  <div className="text-sm text-muted-foreground font-mono">{selectedSymbol}</div>
                </div>
              </div>
            )}
          </div>
          
          {!isLoading && !error && (
            <div className="text-right">
              <div className="text-2xl font-bold">{formatPrice(currentPrice)}</div>
              <div className={cn(
                'flex items-center gap-1 text-sm font-medium',
                priceChange24h >= 0 ? 'text-green-500' : 'text-red-500'
              )}>
                {priceChange24h >= 0 ? 
                  <TrendingUp className="h-4 w-4" /> : 
                  <TrendingDown className="h-4 w-4" />
                }
                {formatChange(priceChange24h)}
              </div>
            </div>
          )}
        </div>

        {/* Symbol Selector */}
        <div className="flex flex-wrap gap-2 pt-2">
          {SUPPORTED_SYMBOLS.map((crypto) => (
            <Button
              key={crypto.symbol}
              variant={selectedSymbol === crypto.symbol ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedSymbol(crypto.symbol)}
              className="h-8 text-xs"
              data-testid={`button-crypto-${crypto.symbol.toLowerCase()}`}
            >
              <span className="mr-1">{crypto.icon}</span>
              {crypto.symbol.replace('USDT', '')}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent>
        <div className="relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 animate-spin" />
                <span>Loading chart data...</span>
              </div>
            </div>
          )}
          
          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
              <div className="text-center text-destructive">
                <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <div className="font-medium">{error}</div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setSelectedSymbol(selectedSymbol)}
                  className="mt-2"
                >
                  Retry
                </Button>
              </div>
            </div>
          )}

          <div 
            ref={chartContainerRef} 
            style={{ height: `${height}px` }}
            className="w-full"
          />
        </div>

        {/* Chart Info */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-green-500 rounded-sm"></div>
              <span>Bullish</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-red-500 rounded-sm"></div>
              <span>Bearish</span>
            </div>
            <Badge variant="outline" className="text-xs">
              15m intervals
            </Badge>
          </div>
          
          <div className="text-xs text-muted-foreground">
            Last updated: {new Date().toLocaleTimeString()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}