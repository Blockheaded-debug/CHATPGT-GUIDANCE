import { useState, useEffect } from "react";
import TradingPairSelector from "./TradingPairSelector";
import SignalDisplay, { type SignalData } from "./SignalDisplay";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, BarChart3, Clock, TrendingUp } from "lucide-react";
import CryptoChart from "./CryptoChart";
import { useQuery } from "@tanstack/react-query";

interface DashboardStats {
  totalAnalyses: number;
  avgConfidence: number;
  activePairs: number;
  avgResponseTime: string;
}

export default function TradingDashboard() {
  const [currentAnalysis, setCurrentAnalysis] = useState<SignalData | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('BTCUSDT');
  const [dashboardStats, setDashboardStats] = useState<DashboardStats>({
    totalAnalyses: 0,
    avgConfidence: 0,
    activePairs: 15,
    avgResponseTime: "0s"
  });

  // Fetch live market stats from backend
  const { data: marketStats } = useQuery({
    queryKey: ['/api/crypto/market-stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Update dashboard stats based on analyses
  useEffect(() => {
    if (currentAnalysis) {
      setDashboardStats(prev => ({
        ...prev,
        totalAnalyses: prev.totalAnalyses + 1,
        avgConfidence: Math.round((prev.avgConfidence + currentAnalysis.confidence) / 2),
      }));
    }
  }, [currentAnalysis]);


  const handleAnalyze = async (pair: string, timeframe: string) => {
    const startTime = Date.now();
    setIsAnalyzing(true);
    setSelectedSymbol(pair); // Update the chart symbol when analyzing a pair
    
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ pair, timeframe }),
      });
      
      if (!response.ok) {
        throw new Error('Analysis failed');
      }
      
      const apiResult = await response.json();
      
      // Transform API response to match SignalData interface
      const result: SignalData = {
        pair: apiResult.pair,
        timeframe: apiResult.timeframe,
        overallSignal: apiResult.signal,
        confidence: apiResult.confidence,
        currentPrice: apiResult.last_price,
        priceChange24h: apiResult.price_change_24h || 0,
        indicators: [
          {
            name: "RSI (14)",
            value: apiResult.indicators.rsi,
            signal: apiResult.indicators.rsi < 30 ? "BUY" : apiResult.indicators.rsi > 70 ? "SELL" : "HOLD",
            description: "Momentum indicator showing current market conditions"
          },
          {
            name: "EMA (12/26)",
            value: apiResult.indicators.ema_short,
            signal: apiResult.indicators.ema_short > apiResult.indicators.ema_long ? "BUY" : "SELL",
            description: "Exponential moving average crossover analysis"
          },
          {
            name: "Stochastic (14,3)",
            value: apiResult.indicators.stoch_k,
            signal: apiResult.indicators.stoch_k < 20 ? "BUY" : apiResult.indicators.stoch_k > 80 ? "SELL" : "HOLD",
            description: "Oscillator indicating overbought/oversold conditions"
          },
          {
            name: "MACD",
            value: apiResult.indicators.macd,
            signal: apiResult.indicators.macd > apiResult.indicators.macd_signal ? "BUY" : "SELL",
            description: "Moving Average Convergence Divergence trend indicator"
          }
        ],
        timestamp: new Date(apiResult.timestamp).toLocaleString() + " UTC",
        reason: apiResult.reason
      };
      
      setCurrentAnalysis(result);
      
      // Update response time stats
      const responseTime = ((Date.now() - startTime) / 1000).toFixed(1);
      setDashboardStats(prev => ({
        ...prev,
        avgResponseTime: `${responseTime}s`
      }));
    } catch (error) {
      console.error('Analysis error:', error);
      // Show error state or fallback
      setCurrentAnalysis(null);
    } finally {
      setIsAnalyzing(false);
    }
  };


  return (
    <div className="space-y-8">
      {/* Dashboard Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Trading Signals Dashboard</h1>
        <p className="text-muted-foreground">
          Analyze cryptocurrency trading pairs with advanced technical indicators
        </p>
      </div>

      {/* Dynamic Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="flex items-center gap-3 p-6">
            <Activity className="h-8 w-8 text-primary" />
            <div>
              <div className="text-2xl font-bold" data-testid="text-analyses-count">
                {dashboardStats.totalAnalyses}
              </div>
              <div className="text-sm text-muted-foreground">Analyses Today</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-6">
            <TrendingUp className="h-8 w-8 text-primary" />
            <div>
              <div className="text-2xl font-bold" data-testid="text-avg-confidence">
                {dashboardStats.avgConfidence > 0 ? `${dashboardStats.avgConfidence}%` : '--'}
              </div>
              <div className="text-sm text-muted-foreground">Avg Confidence</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-6">
            <BarChart3 className="h-8 w-8 text-primary" />
            <div>
              <div className="text-2xl font-bold" data-testid="text-active-pairs">
                {marketStats?.data?.length || dashboardStats.activePairs}
              </div>
              <div className="text-sm text-muted-foreground">Active Pairs</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-6">
            <Clock className="h-8 w-8 text-primary" />
            <div>
              <div className="text-2xl font-bold" data-testid="text-response-time">
                {dashboardStats.avgResponseTime}
              </div>
              <div className="text-sm text-muted-foreground">Avg Response</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Real-time Crypto Chart */}
      <CryptoChart 
        symbol={selectedSymbol} 
        height={500}
        className="w-full"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Trading Pair Selector */}
        <div className="lg:col-span-1">
          <TradingPairSelector onAnalyze={handleAnalyze} isLoading={isAnalyzing} />
        </div>

        {/* Analysis Results */}
        <div className="lg:col-span-2">
          {isAnalyzing ? (
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center space-y-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <div className="text-muted-foreground">Analyzing market data and generating signals...</div>
                </div>
              </CardContent>
            </Card>
          ) : currentAnalysis ? (
            <SignalDisplay data={currentAnalysis} />
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center space-y-2">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto" />
                  <div className="text-lg font-medium text-muted-foreground">
                    Select a trading pair to begin analysis
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Choose from popular pairs or enter a custom trading pair
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}