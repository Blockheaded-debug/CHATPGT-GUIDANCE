import TradingDashboard from '../TradingDashboard';

export default function TradingDashboardExample() {
  return <TradingDashboard />;
}