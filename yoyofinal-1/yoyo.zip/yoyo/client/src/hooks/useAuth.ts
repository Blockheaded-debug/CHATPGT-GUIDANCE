import { useState, useEffect } from "react";

interface User {
  username: string;
  authenticated: boolean;
  sessionExpiry?: number;
}

// Static credentials as specified
const VALID_CREDENTIALS = {
  username: "nexus_admin",
  password: "Crypto$2024#Vault"
};

const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session on component mount
    const storedSession = localStorage.getItem('signalstream_session');
    if (storedSession) {
      try {
        const session = JSON.parse(storedSession);
        const now = Date.now();
        
        // Check if session is still valid
        if (session.sessionExpiry && now < session.sessionExpiry) {
          setUser({
            username: session.username,
            authenticated: true,
            sessionExpiry: session.sessionExpiry
          });
        } else {
          // Session expired, remove it
          localStorage.removeItem('signalstream_session');
        }
      } catch (error) {
        console.error('Failed to parse stored session:', error);
        localStorage.removeItem('signalstream_session');
      }
    }
    setIsLoading(false);
  }, []);

  const login = (username: string, password: string): boolean => {
    if (username === VALID_CREDENTIALS.username && password === VALID_CREDENTIALS.password) {
      const sessionExpiry = Date.now() + SESSION_DURATION;
      const session = {
        username: VALID_CREDENTIALS.username,
        authenticated: true,
        sessionExpiry
      };

      localStorage.setItem('signalstream_session', JSON.stringify(session));
      setUser(session);
      return true;
    }
    return false;
  };

  const logout = () => {
    localStorage.removeItem('signalstream_session');
    setUser(null);
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user?.authenticated,
    login,
    logout
  };
}