// Optimized crypto API client that leverages backend endpoints with caching and rate limiting
// This replaces direct external API calls with backend integration

interface BackendCryptoData {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  timestamp: number;
}

interface BackendCandlestickData {
  symbol: string;
  interval: string;
  data: Array<{
    timestamp: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }>;
  lastUpdated: number;
}

interface BackendApiResponse<T> {
  success: boolean;
  data: T;
  timestamp: number;
}

class BackendCryptoApiClient {
  private readonly baseUrl: string;
  
  constructor() {
    this.baseUrl = ''; // Use relative URLs for same-origin requests
  }

  private async makeRequest<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Backend API error (${response.status}): ${errorText}`);
    }

    const result: BackendApiResponse<T> = await response.json();
    
    if (!result.success) {
      throw new Error('Backend API returned error response');
    }

    return result.data;
  }

  async getCurrentPrice(symbol: string): Promise<{ price: number; change24h: number }> {
    try {
      const data = await this.makeRequest<BackendCryptoData>(`/api/crypto/price/${symbol}`);
      return {
        price: data.price,
        change24h: data.change24h
      };
    } catch (error) {
      console.warn(`Backend price fetch failed for ${symbol}, using fallback:`, error);
      // Fallback to existing frontend API if backend fails
      return { price: 0, change24h: 0 };
    }
  }

  async getCurrentPrices(symbols: string[]): Promise<BackendCryptoData[]> {
    try {
      const symbolsQuery = symbols.join(',');
      return await this.makeRequest<BackendCryptoData[]>(`/api/crypto/prices?symbols=${symbolsQuery}`);
    } catch (error) {
      console.warn('Backend prices fetch failed, using fallback:', error);
      return [];
    }
  }

  async getCandlestickData(
    symbol: string, 
    interval: string = '15m', 
    limit: number = 200
  ): Promise<Array<{ time: number; open: number; high: number; low: number; close: number; volume?: number }>> {
    try {
      const data = await this.makeRequest<BackendCandlestickData>(
        `/api/crypto/candlesticks/${symbol}?interval=${interval}&limit=${limit}`
      );

      // Transform backend format to frontend format
      return data.data.map(item => ({
        time: item.timestamp,
        open: item.open,
        high: item.high,
        low: item.low,
        close: item.close,
        volume: item.volume
      }));
    } catch (error) {
      console.warn(`Backend candlestick fetch failed for ${symbol}, using fallback:`, error);
      return [];
    }
  }

  async getMarketStats(): Promise<any[]> {
    try {
      return await this.makeRequest<any[]>('/api/crypto/market-stats');
    } catch (error) {
      console.warn('Backend market stats fetch failed:', error);
      return [];
    }
  }

  // Real-time price subscription with backend integration
  subscribeToPrice(
    symbol: string, 
    callback: (price: number, change24h: number) => void
  ): () => void {
    let isSubscribed = true;

    const updatePrice = async () => {
      if (!isSubscribed) return;

      try {
        const { price, change24h } = await this.getCurrentPrice(symbol);
        if (isSubscribed && price > 0) {
          callback(price, change24h);
        }
      } catch (error) {
        console.warn(`Price update failed for ${symbol}:`, error);
      }
    };

    // Initial load
    updatePrice();

    // Set up polling every 5 seconds (backend handles rate limiting)
    const interval = setInterval(updatePrice, 5000);

    // Return unsubscribe function
    return () => {
      isSubscribed = false;
      clearInterval(interval);
    };
  }
}

// Export singleton instance
export const backendCryptoApi = new BackendCryptoApiClient();
export default backendCryptoApi;