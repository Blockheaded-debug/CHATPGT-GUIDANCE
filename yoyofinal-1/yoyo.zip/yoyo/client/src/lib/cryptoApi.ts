interface PriceData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

interface CryptoPriceResponse {
  symbol: string;
  currentPrice: number;
  priceChange24h: number;
  volume24h: number;
  candlesticks: PriceData[];
}

interface ApiConfig {
  name: string;
  baseUrl: string;
  rateLimit: {
    requestsPerSecond: number;
    burstLimit: number;
  };
}

// Multi-API configuration with fallback priority
// For candlestick data, prefer Binance for intraday intervals
const API_CONFIGS: ApiConfig[] = [
  {
    name: 'Binance',
    baseUrl: 'https://api.binance.com/api/v3',
    rateLimit: { requestsPerSecond: 10, burstLimit: 100 }
  },
  {
    name: 'CoinGecko',
    baseUrl: 'https://api.coingecko.com/api/v3',
    rateLimit: { requestsPerSecond: 0.17, burstLimit: 10 } // ~10 requests per minute
  }
];

// Separate config for price data (CoinGecko preferred for accuracy)
const PRICE_API_CONFIGS: ApiConfig[] = [
  {
    name: 'CoinGecko',
    baseUrl: 'https://api.coingecko.com/api/v3',
    rateLimit: { requestsPerSecond: 0.17, burstLimit: 10 }
  },
  {
    name: 'Binance',
    baseUrl: 'https://api.binance.com/api/v3',
    rateLimit: { requestsPerSecond: 10, burstLimit: 100 }
  }
];

class RateLimiter {
  private requestQueue: Array<{ resolve: Function; reject: Function }> = [];
  private lastRequestTime = 0;
  private requestCount = 0;
  private readonly config: ApiConfig['rateLimit'];

  constructor(config: ApiConfig['rateLimit']) {
    this.config = config;
  }

  async throttle(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.requestQueue.push({ resolve, reject });
      this.processQueue();
    });
  }

  // Exponential backoff with jitter for failed requests
  async retryWithBackoff<T>(
    fn: () => Promise<T>,
    maxRetries: number = 3,
    baseDelay: number = 1000
  ): Promise<T> {
    let lastError: Error;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        await this.throttle();
        return await fn();
      } catch (error) {
        lastError = error as Error;
        
        // Don't retry on non-retryable errors
        if (error instanceof Error) {
          const message = error.message.toLowerCase();
          if (message.includes('404') || message.includes('unauthorized')) {
            throw error;
          }
        }
        
        if (attempt === maxRetries) {
          throw lastError;
        }
        
        // Exponential backoff with jitter
        const backoffDelay = Math.min(
          baseDelay * Math.pow(2, attempt),
          30000 // Max 30 seconds
        );
        const jitter = Math.random() * 0.3 * backoffDelay; // ±30% jitter
        const delayWithJitter = backoffDelay + jitter;
        
        console.warn(`Request failed (attempt ${attempt + 1}/${maxRetries + 1}), retrying in ${Math.round(delayWithJitter)}ms:`, error);
        await new Promise(resolve => setTimeout(resolve, delayWithJitter));
      }
    }
    
    throw lastError!;
  }

  private processQueue() {
    if (this.requestQueue.length === 0) return;

    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    const minInterval = 1000 / this.config.requestsPerSecond;

    if (timeSinceLastRequest >= minInterval) {
      const { resolve } = this.requestQueue.shift()!;
      this.lastRequestTime = now;
      this.requestCount++;
      resolve();
      
      // Process next request
      if (this.requestQueue.length > 0) {
        setTimeout(() => this.processQueue(), minInterval);
      }
    } else {
      setTimeout(() => this.processQueue(), minInterval - timeSinceLastRequest);
    }
  }
}

class CryptoAPIClient {
  private rateLimiters: Map<string, RateLimiter> = new Map();
  private cache: Map<string, { data: any; expiry: number }> = new Map();
  private readonly CACHE_DURATION = 30 * 1000; // 30 seconds
  // Remove global currentApiIndex to fix race condition

  constructor() {
    // Initialize rate limiters for all API configs
    [...API_CONFIGS, ...PRICE_API_CONFIGS].forEach(config => {
      if (!this.rateLimiters.has(config.name)) {
        this.rateLimiters.set(config.name, new RateLimiter(config.rateLimit));
      }
    });
  }

  private getCacheKey(endpoint: string, params?: Record<string, any>): string {
    return `${endpoint}_${JSON.stringify(params || {})}`;
  }

  private getCachedData(key: string): any | null {
    const cached = this.cache.get(key);
    if (cached && Date.now() < cached.expiry) {
      return cached.data;
    }
    this.cache.delete(key);
    return null;
  }

  private setCachedData(key: string, data: any): void {
    this.cache.set(key, {
      data,
      expiry: Date.now() + this.CACHE_DURATION
    });
  }

  private async makeRequest(url: string, apiConfig: ApiConfig): Promise<any> {
    const rateLimiter = this.rateLimiters.get(apiConfig.name)!;
    
    return rateLimiter.retryWithBackoff(async () => {
      const response = await fetch(url);
      
      if (response.status === 429) {
        throw new Error('Rate limit exceeded');
      }

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    });
  }

  private async makeRequestWithFallback(
    getUrl: (config: ApiConfig) => string,
    cacheKey?: string,
    apiConfigs: ApiConfig[] = API_CONFIGS
  ): Promise<{ data: any; usedApi: string }> {
    // Check cache first
    if (cacheKey) {
      const cached = this.getCachedData(cacheKey);
      if (cached) return { data: cached.data, usedApi: cached.usedApi };
    }

    let lastError: Error | null = null;

    // Try each API in priority order
    for (const config of apiConfigs) {
      try {
        const url = getUrl(config);
        const data = await this.makeRequest(url, config);
        
        // Cache successful response with API info
        if (cacheKey) {
          this.setCachedData(cacheKey, { data, usedApi: config.name });
        }
        
        return { data, usedApi: config.name };
      } catch (error) {
        lastError = error as Error;
        console.warn(`API ${config.name} failed, trying next...`);
      }
    }

    throw lastError || new Error('All APIs failed');
  }

  async getCurrentPrice(symbol: string): Promise<{ price: number; change24h: number }> {
    const cacheKey = this.getCacheKey('current_price', { symbol });

    const { data, usedApi } = await this.makeRequestWithFallback(
      (config) => {
        if (config.name === 'CoinGecko') {
          const coinId = this.symbolToCoinGeckoId(symbol);
          return `${config.baseUrl}/simple/price?ids=${coinId}&vs_currencies=usd&include_24hr_change=true`;
        } else if (config.name === 'Binance') {
          return `${config.baseUrl}/ticker/24hr?symbol=${symbol}`;
        }
        throw new Error(`Unsupported API: ${config.name}`);
      },
      cacheKey,
      PRICE_API_CONFIGS // Prefer CoinGecko for price accuracy
    );

    // Transform response based on which API was used
    if (usedApi === 'CoinGecko') {
      const coinId = this.symbolToCoinGeckoId(symbol);
      const coinData = data[coinId];
      return {
        price: coinData.usd,
        change24h: coinData.usd_24h_change || 0
      };
    } else if (usedApi === 'Binance') {
      return {
        price: parseFloat(data.lastPrice),
        change24h: parseFloat(data.priceChangePercent)
      };
    } else {
      throw new Error(`Unsupported API response from: ${usedApi}`);
    }
  }

  async getCandlestickData(symbol: string, interval: string = '15m', limit: number = 200): Promise<PriceData[]> {
    const cacheKey = this.getCacheKey('candlestick', { symbol, interval, limit });

    // Check if interval is intraday (prefer Binance) or daily (CoinGecko acceptable)
    const isIntradayInterval = !['1d', '1w', '1M'].includes(interval);
    
    let data: any;
    let usedApi: string;
    
    if (isIntradayInterval) {
      // For intraday intervals (like 15m), strongly prefer Binance
      try {
        const result = await this.makeRequestWithFallback(
          (config) => {
            if (config.name === 'Binance') {
              return `${config.baseUrl}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
            }
            throw new Error(`API ${config.name} doesn't support intraday interval ${interval}`);
          },
          cacheKey,
          API_CONFIGS.filter(c => c.name === 'Binance') // Only try Binance for intraday
        );
        data = result.data;
        usedApi = result.usedApi;
      } catch (error) {
        // Fallback to CoinGecko daily data with warning
        console.warn(`Binance failed for intraday ${interval}, falling back to CoinGecko daily data`);
        const result = await this.makeRequestWithFallback(
          (config) => {
            if (config.name === 'CoinGecko') {
              const coinId = this.symbolToCoinGeckoId(symbol);
              return `${config.baseUrl}/coins/${coinId}/ohlc?vs_currency=usd&days=7`;
            }
            throw new Error(`Unsupported API: ${config.name}`);
          },
          this.getCacheKey('candlestick_fallback', { symbol, interval: '1d', limit }),
          API_CONFIGS.filter(c => c.name === 'CoinGecko')
        );
        data = result.data;
        usedApi = result.usedApi;
      }
    } else {
      // For daily intervals, can use either API
      const result = await this.makeRequestWithFallback(
        (config) => {
          if (config.name === 'Binance') {
            return `${config.baseUrl}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
          } else if (config.name === 'CoinGecko') {
            const coinId = this.symbolToCoinGeckoId(symbol);
            const days = interval === '1w' ? 30 : interval === '1M' ? 365 : 7;
            return `${config.baseUrl}/coins/${coinId}/ohlc?vs_currency=usd&days=${days}`;
          }
          throw new Error(`Unsupported API: ${config.name}`);
        },
        cacheKey
      );
      data = result.data;
      usedApi = result.usedApi;
    }

    // Transform response based on which API was used
    if (usedApi === 'CoinGecko' && Array.isArray(data)) {
      return data.map(([timestamp, open, high, low, close]) => ({
        time: timestamp,
        open,
        high,
        low,
        close
      }));
    } else if (usedApi === 'Binance' && Array.isArray(data)) {
      return data.map(([timestamp, open, high, low, close, volume]) => ({
        time: parseInt(timestamp),
        open: parseFloat(open),
        high: parseFloat(high),
        low: parseFloat(low),
        close: parseFloat(close),
        volume: parseFloat(volume)
      }));
    }

    return [];
  }

  private symbolToCoinGeckoId(symbol: string): string {
    const symbolMap: Record<string, string> = {
      'BTCUSDT': 'bitcoin',
      'ETHUSDT': 'ethereum',
      'BNBUSDT': 'binancecoin',
      'ADAUSDT': 'cardano',
      'DOTUSDT': 'polkadot',
      'LINKUSDT': 'chainlink',
      'MATICUSDT': 'matic-network'
    };
    
    return symbolMap[symbol] || symbol.replace('USDT', '').toLowerCase();
  }
}

export const cryptoApi = new CryptoAPIClient();

// Real-time price update manager
export class PriceUpdateManager {
  private updateCallbacks: Map<string, Function[]> = new Map();
  private updateIntervals: Map<string, ReturnType<typeof setInterval>> = new Map();
  private readonly UPDATE_INTERVAL = 5000; // 5 seconds

  subscribe(symbol: string, callback: (price: number, change24h: number) => void): () => void {
    if (!this.updateCallbacks.has(symbol)) {
      this.updateCallbacks.set(symbol, []);
      this.startUpdates(symbol);
    }

    const callbacks = this.updateCallbacks.get(symbol)!;
    callbacks.push(callback);

    // Return unsubscribe function
    return () => {
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
        
        // Stop updates if no more subscribers
        if (callbacks.length === 0) {
          this.stopUpdates(symbol);
        }
      }
    };
  }

  private startUpdates(symbol: string) {
    const interval = setInterval(async () => {
      try {
        const { price, change24h } = await cryptoApi.getCurrentPrice(symbol);
        const callbacks = this.updateCallbacks.get(symbol) || [];
        callbacks.forEach(callback => callback(price, change24h));
      } catch (error) {
        console.error(`Failed to update price for ${symbol}:`, error);
      }
    }, this.UPDATE_INTERVAL);

    this.updateIntervals.set(symbol, interval);
  }

  private stopUpdates(symbol: string) {
    const interval = this.updateIntervals.get(symbol);
    if (interval) {
      clearInterval(interval);
      this.updateIntervals.delete(symbol);
      this.updateCallbacks.delete(symbol);
    }
  }
}

export const priceUpdater = new PriceUpdateManager();