import { storage, type CryptoData, type CandlestickData } from "./storage";

// Backend crypto API service with caching and rate limiting
export class CryptoApiService {
  private readonly BINANCE_BASE_URL = 'https://api.binance.com';
  private readonly COINGECKO_BASE_URL = 'https://api.coingecko.com/api/v3';
  
  // Rate limiting tracking
  private requestCounts = new Map<string, { count: number; resetTime: number }>();
  private readonly RATE_LIMIT = 50; // requests per minute per API
  private readonly RATE_WINDOW = 60 * 1000; // 1 minute

  private async makeRateLimitedRequest(url: string, apiName: string): Promise<any> {
    const now = Date.now();
    const key = `${apiName}_${Math.floor(now / this.RATE_WINDOW)}`;
    
    const current = this.requestCounts.get(key) || { count: 0, resetTime: now + this.RATE_WINDOW };
    
    if (current.count >= this.RATE_LIMIT) {
      throw new Error(`Rate limit exceeded for ${apiName}. Please try again later.`);
    }
    
    current.count++;
    this.requestCounts.set(key, current);
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }
    
    return response.json();
  }

  async getCurrentPrices(symbols: string[]): Promise<CryptoData[]> {
    const results: CryptoData[] = [];
    
    for (const symbol of symbols) {
      try {
        // Check cache first
        const cached = await storage.getCryptoPrice(symbol);
        if (cached) {
          results.push(cached);
          continue;
        }

        // Fetch from Binance first
        try {
          const binanceSymbol = symbol.replace('USDT', 'USDT');
          const priceData = await this.makeRateLimitedRequest(
            `${this.BINANCE_BASE_URL}/api/v3/ticker/24hr?symbol=${binanceSymbol}`,
            'binance'
          );

          const cryptoData: CryptoData = {
            symbol,
            price: parseFloat(priceData.lastPrice),
            change24h: parseFloat(priceData.priceChangePercent),
            volume24h: parseFloat(priceData.volume),
            timestamp: Date.now()
          };

          await storage.setCryptoPrice(cryptoData);
          results.push(cryptoData);
        } catch (binanceError) {
          // Fallback to CoinGecko
          console.warn(`Binance failed for ${symbol}, trying CoinGecko:`, binanceError);
          
          const coinId = this.symbolToCoinGeckoId(symbol);
          const cgData = await this.makeRateLimitedRequest(
            `${this.COINGECKO_BASE_URL}/simple/price?ids=${coinId}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true`,
            'coingecko'
          );

          if (cgData[coinId]) {
            const cryptoData: CryptoData = {
              symbol,
              price: cgData[coinId].usd,
              change24h: cgData[coinId].usd_24h_change || 0,
              volume24h: cgData[coinId].usd_24h_vol || 0,
              timestamp: Date.now()
            };

            await storage.setCryptoPrice(cryptoData);
            results.push(cryptoData);
          }
        }
      } catch (error) {
        console.error(`Failed to fetch price for ${symbol}:`, error);
        // Continue with other symbols
      }
    }

    return results;
  }

  async getCandlestickData(symbol: string, interval = '15m', limit = 100): Promise<CandlestickData | null> {
    try {
      // Check cache first
      const cached = await storage.getCandlestickData(symbol, interval);
      if (cached) {
        return cached;
      }

      // Fetch from Binance (better for intraday data)
      try {
        const binanceSymbol = symbol.replace('USDT', 'USDT');
        const klineData = await this.makeRateLimitedRequest(
          `${this.BINANCE_BASE_URL}/api/v3/klines?symbol=${binanceSymbol}&interval=${interval}&limit=${limit}`,
          'binance'
        );

        const candlestickData: CandlestickData = {
          symbol,
          interval,
          data: klineData.map((kline: any[]) => ({
            timestamp: kline[0],
            open: parseFloat(kline[1]),
            high: parseFloat(kline[2]),
            low: parseFloat(kline[3]),
            close: parseFloat(kline[4]),
            volume: parseFloat(kline[5])
          })),
          lastUpdated: Date.now()
        };

        await storage.setCandlestickData(candlestickData);
        return candlestickData;
      } catch (binanceError) {
        console.warn(`Binance candlestick failed for ${symbol}, trying CoinGecko:`, binanceError);
        
        // Fallback to CoinGecko (daily data only)
        const coinId = this.symbolToCoinGeckoId(symbol);
        const cgData = await this.makeRateLimitedRequest(
          `${this.COINGECKO_BASE_URL}/coins/${coinId}/market_chart?vs_currency=usd&days=30`,
          'coingecko'
        );

        if (cgData.prices && cgData.prices.length > 0) {
          const candlestickData: CandlestickData = {
            symbol,
            interval: '1d', // CoinGecko provides daily data
            data: cgData.prices.map((price: [number, number], index: number) => ({
              timestamp: price[0],
              open: price[1],
              high: price[1], // CoinGecko doesn't provide OHLC, using price
              low: price[1],
              close: price[1],
              volume: cgData.total_volumes?.[index]?.[1] || 0
            })),
            lastUpdated: Date.now()
          };

          await storage.setCandlestickData(candlestickData);
          return candlestickData;
        }
      }
    } catch (error) {
      console.error(`Failed to fetch candlestick data for ${symbol}:`, error);
    }

    return null;
  }

  async getMarketStats(): Promise<any> {
    try {
      const binanceStats = await this.makeRateLimitedRequest(
        `${this.BINANCE_BASE_URL}/api/v3/ticker/24hr`,
        'binance'
      );

      // Return top 10 by volume
      return binanceStats
        .sort((a: any, b: any) => parseFloat(b.quoteVolume) - parseFloat(a.quoteVolume))
        .slice(0, 10)
        .map((ticker: any) => ({
          symbol: ticker.symbol,
          price: parseFloat(ticker.lastPrice),
          change24h: parseFloat(ticker.priceChangePercent),
          volume24h: parseFloat(ticker.quoteVolume)
        }));
    } catch (error) {
      console.error('Failed to fetch market stats:', error);
      return [];
    }
  }

  private symbolToCoinGeckoId(symbol: string): string {
    const mapping: { [key: string]: string } = {
      'BTCUSDT': 'bitcoin',
      'ETHUSDT': 'ethereum',
      'ADAUSDT': 'cardano',
      'DOTUSDT': 'polkadot',
      'LINKUSDT': 'chainlink',
      'BNBUSDT': 'binancecoin',
      'SOLUSDT': 'solana',
      'MATICUSDT': 'polygon',
      'AVAXUSDT': 'avalanche-2',
      'LTCUSDT': 'litecoin',
      'XRPUSDT': 'ripple',
      'ATOMUSDT': 'cosmos',
      'ALGOUSDT': 'algorand',
      'VETUSDT': 'vechain',
      'FILUSDT': 'filecoin'
    };

    return mapping[symbol] || symbol.replace('USDT', '').toLowerCase();
  }
}

export const cryptoApiService = new CryptoApiService();