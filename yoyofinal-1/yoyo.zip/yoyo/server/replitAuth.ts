// DEPRECATED: This file is no longer used after migrating to static authentication
// All Replit OIDC functionality has been replaced with static credentials

import type { Express, RequestHandler } from "express";

// Stub functions to maintain compatibility during migration
export async function setupAuth(app: Express): Promise<void> {
  // No-op: Static authentication is handled in the frontend
  console.log("Static authentication enabled - no server-side auth setup needed");
}

export const isAuthenticated: RequestHandler = (req, res, next) => {
  // No-op: All routes are accessible with static authentication
  next();
};

// Legacy function stubs (not used)
export function getSession() {
  throw new Error("Session management is deprecated - using static authentication");
}