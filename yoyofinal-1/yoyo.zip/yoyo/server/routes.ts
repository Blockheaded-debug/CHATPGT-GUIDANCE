import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { spawn } from "child_process";
import path from "path";
import rateLimit from "express-rate-limit";
import { cryptoApiService } from "./cryptoService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Rate limiting middleware
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: {
      error: 'Too many requests from this IP, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
  });

  const cryptoLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute  
    max: 30, // limit crypto API calls to 30 per minute per IP
    message: {
      error: 'Too many crypto API requests, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
  });

  // Apply rate limiting to all API routes
  app.use('/api', apiLimiter);
  app.use('/api/crypto', cryptoLimiter);

  // Static authentication status endpoint (no actual auth needed)
  app.get('/api/auth/user', async (req, res) => {
    // Return static user info for the crypto trading platform
    res.json({
      id: 'nexus_admin',
      username: 'nexus_admin',
      isAuthenticated: true,
      role: 'admin'
    });
  });

  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.getUser(id) or storage.upsertUser(user)

  // Crypto Signal Analysis Route
  app.post('/api/analyze', async (req, res) => {
    try {
      const { pair, timeframe = '15m' } = req.body;
      
      if (!pair) {
        return res.status(400).json({ error: 'Trading pair is required' });
      }

      // Call Python analysis script
      const pythonScript = path.join(process.cwd(), 'python_backend', 'analyze_pair.py');
      const python = spawn('python', [pythonScript, pair, timeframe]);
      
      let output = '';
      let errorOutput = '';
      
      python.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      python.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });
      
      python.on('close', (code) => {
        if (code !== 0) {
          console.error('Python script error:', errorOutput);
          return res.status(500).json({
            error: 'Analysis failed',
            details: errorOutput
          });
        }
        
        try {
          const result = JSON.parse(output);
          res.json(result);
        } catch (parseError) {
          console.error('Failed to parse Python output:', output);
          res.status(500).json({
            error: 'Failed to parse analysis result'
          });
        }
      });
      
    } catch (error) {
      console.error('Analysis route error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Get supported trading pairs
  app.get('/api/pairs', (req, res) => {
    const popularPairs = [
      'BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'DOTUSDT', 'LINKUSDT',
      'BNBUSDT', 'SOLUSDT', 'MATICUSDT', 'AVAXUSDT', 'LTCUSDT',
      'XRPUSDT', 'ATOMUSDT', 'ALGOUSDT', 'VETUSDT', 'FILUSDT'
    ];
    
    res.json({
      pairs: popularPairs,
      supported_timeframes: ['15m'],
      default_timeframe: '15m'
    });
  });

  // Crypto API endpoints with backend integration
  app.get('/api/crypto/prices', async (req, res) => {
    try {
      const symbols = req.query.symbols as string;
      if (!symbols) {
        return res.status(400).json({ error: 'symbols parameter is required' });
      }

      const symbolArray = symbols.split(',').map(s => s.trim().toUpperCase());
      const prices = await cryptoApiService.getCurrentPrices(symbolArray);
      
      res.json({
        success: true,
        data: prices,
        timestamp: Date.now()
      });
    } catch (error) {
      console.error('Crypto prices API error:', error);
      res.status(500).json({
        error: 'Failed to fetch crypto prices',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get('/api/crypto/candlesticks/:symbol', async (req, res) => {
    try {
      const { symbol } = req.params;
      const interval = req.query.interval as string || '15m';
      const limit = parseInt(req.query.limit as string) || 100;

      if (!symbol) {
        return res.status(400).json({ error: 'symbol parameter is required' });
      }

      const candlesticks = await cryptoApiService.getCandlestickData(
        symbol.toUpperCase(), 
        interval, 
        limit
      );
      
      if (!candlesticks) {
        return res.status(404).json({ error: 'Candlestick data not found' });
      }

      res.json({
        success: true,
        data: candlesticks,
        timestamp: Date.now()
      });
    } catch (error) {
      console.error('Crypto candlesticks API error:', error);
      res.status(500).json({
        error: 'Failed to fetch candlestick data',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get('/api/crypto/market-stats', async (req, res) => {
    try {
      const stats = await cryptoApiService.getMarketStats();
      
      res.json({
        success: true,
        data: stats,
        timestamp: Date.now()
      });
    } catch (error) {
      console.error('Market stats API error:', error);
      res.status(500).json({
        error: 'Failed to fetch market statistics',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get('/api/crypto/price/:symbol', async (req, res) => {
    try {
      const { symbol } = req.params;
      
      if (!symbol) {
        return res.status(400).json({ error: 'symbol parameter is required' });
      }

      const prices = await cryptoApiService.getCurrentPrices([symbol.toUpperCase()]);
      
      if (prices.length === 0) {
        return res.status(404).json({ error: 'Price data not found for symbol' });
      }

      res.json({
        success: true,
        data: prices[0],
        timestamp: Date.now()
      });
    } catch (error) {
      console.error('Single crypto price API error:', error);
      res.status(500).json({
        error: 'Failed to fetch crypto price',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
