import {
  users,
  type User,
  type UpsertUser,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Crypto data types
export interface CryptoData {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  timestamp: number;
}

export interface CandlestickData {
  symbol: string;
  interval: string;
  data: Array<{
    timestamp: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }>;
  lastUpdated: number;
}

// Interface for storage operations
export interface IStorage {
  // Simplified user operations (optional for static auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Crypto data operations (primary focus)
  getCryptoPrice(symbol: string): Promise<CryptoData | undefined>;
  setCryptoPrice(data: CryptoData): Promise<void>;
  getCandlestickData(symbol: string, interval: string): Promise<CandlestickData | undefined>;
  setCandlestickData(data: CandlestickData): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // In-memory cache for crypto data (5 minute TTL)
  private cryptoCache = new Map<string, { data: CryptoData; expiry: number }>();
  private candlestickCache = new Map<string, { data: CandlestickData; expiry: number }>();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  // Simplified user operations (for static auth system)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          lastLogin: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Crypto data operations with in-memory caching
  async getCryptoPrice(symbol: string): Promise<CryptoData | undefined> {
    const cached = this.cryptoCache.get(symbol);
    if (cached && cached.expiry > Date.now()) {
      return cached.data;
    }
    return undefined;
  }

  async setCryptoPrice(data: CryptoData): Promise<void> {
    this.cryptoCache.set(data.symbol, {
      data,
      expiry: Date.now() + this.CACHE_TTL
    });
  }

  async getCandlestickData(symbol: string, interval: string): Promise<CandlestickData | undefined> {
    const key = `${symbol}_${interval}`;
    const cached = this.candlestickCache.get(key);
    if (cached && cached.expiry > Date.now()) {
      return cached.data;
    }
    return undefined;
  }

  async setCandlestickData(data: CandlestickData): Promise<void> {
    const key = `${data.symbol}_${data.interval}`;
    this.candlestickCache.set(key, {
      data,
      expiry: Date.now() + this.CACHE_TTL
    });
  }
}

export const storage = new DatabaseStorage();
