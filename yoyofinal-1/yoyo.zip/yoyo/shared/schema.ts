import { sql } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Simplified schema for crypto trading platform with static authentication
// Note: Sessions table removed since we use static authentication

// Simplified user table for basic user tracking (optional)
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  username: varchar("username").unique(),
  role: varchar("role").default("user"),
  createdAt: timestamp("created_at").defaultNow(),
  lastLogin: timestamp("last_login"),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
